# PKMN Move Finder
As the title suggests, it helps find pokemon moves. 
The program returns a list of pokemons having in common your selected moves

For example, after entering 'Yawn' and 'Amnesia', we have as a result : 

{'Numel', 'Slaking', 'Slakoth', 'Snorlax', 'Magcargo', 'Slowking', 'Clodsire', 'Psyduck', 'Golduck', 'Torkoal', 'Cetitan', 'Swalot', 'Dunsparce', 'Gastrodon', 'Uxie', 'Slowbro', 'Quagsire', 'Dudunsparce', 'Gulpin', 'Wooper', 'Slugma', 'Hippowdon', 'Mudkip', 'Slowpoke', 'Cetoddle', 'Shellos', 'Hippopotas', 'Camerupt'}

So all the pokemons that share those two moves


## TODO 
still have to make an edge case when the user enters an invalid move name


## Thanks
thanks to the devs and moderator of the pokemon db website for its amazing structure, making it 
really easy to navigate around browsing and selecting pokemons

### author
free thing lmao you could do this yourself in like 2 hours

Socials here just in case
=> [Gelehead](https://github.com/Gelehead)
